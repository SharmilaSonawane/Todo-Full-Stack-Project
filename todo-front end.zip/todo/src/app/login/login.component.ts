import { Component } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
//username :string = "Sharmila" ;
//Password: string="Sharmila@123"

username = "Sharmila";
password ="";
invalidLogin =false;
errormessage="invalid credentials";

//inject an object(@Autowired in spring boot)
constructor(private router:Router){}


handleLogin(){
  // console.log(this.username);
  // console.log(this.password);
  if(this.username==='Sharmila' && this.password==='Sharmila@123'){
    //console.log('Valid User');
    //this.invalidLogin=false;
    //Redirect to welcome page
     this.router.navigate(['welcome',this.username]);
  }
  else{
    //console.log('Invalid User');
    this.invalidLogin=true;
  }
}
}
