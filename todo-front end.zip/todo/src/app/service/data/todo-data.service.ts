import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Todo } from 'src/app/list-to-dos/list-to-dos.component';

@Injectable({
  providedIn: 'root'
})
export class TodoDataService {

  constructor(private httpClient:HttpClient) { }

  retriveAllTodos(){
    return this.httpClient.get<Todo[]>(`http://localhost:8889/getAllTodo`);
  }

  deleteTodo(id:number){
    return this.httpClient.delete(`http://localhost:8889/deletebyid/${id}`);
  }


  //findToDoById
  retriveToDo(id:number){ //call this from todo.ts

    return this.httpClient.get<Todo>(`http://localhost:8889/findbyid/${id}`);

  }


  //updateRecord

  updateTodo(id: number, todo: Todo) {
    return this.httpClient.put<Todo>(`http://localhost:8889/updatetodo/${id}`,todo);
                                
  }

  addTodo(todo: Todo){
    return this.httpClient.post<Todo>(`http://localhost:8889/addTodo`,todo);       
}
  
}
