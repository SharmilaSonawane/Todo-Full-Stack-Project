import { Component, OnInit } from '@angular/core';
import { TodoDataService } from '../service/data/todo-data.service';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { Todo } from '../list-to-dos/list-to-dos.component';

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit{
  
  id:number;
  todo:Todo;

  constructor(private todoService:TodoDataService,private route:ActivatedRoute,private router:Router){}
   ngOnInit(): void {
     this.id=this.route.snapshot.params['id'];//read from url
     //avoid errors
     this.todo=new Todo(this.id,'','',false,new Date());
     //if id!=-1 then only get the records
    
     if(this.id!=-1){

      console.log(this.id); //initially on form load get the data (first)
     this.todoService.retriveToDo(this.id).subscribe(
       data=>this.todo=data
     
     )
     }
     

   }

   saveToDo(){

    //for update and save based on id of URL if id=-1 add record else update
    if(this.id==-1){
      //add record
      this.todoService.addTodo(this.todo).subscribe(
        data=>this.router.navigate(['todos']) //navigate to todos page
      )
    }  
    //update record
    else{
    
    this.todoService.updateTodo(this.id,this.todo).subscribe(
        data=>{
          console.log(data)
        //after update navigate to todo component ,inject an object of todo
      this.router.navigate(['todos'])
        }
        )
  }
}

   }
  






