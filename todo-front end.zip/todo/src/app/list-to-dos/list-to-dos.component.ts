import { Component, OnInit } from '@angular/core';
import { TodoDataService } from '../service/data/todo-data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-to-dos',
  templateUrl: './list-to-dos.component.html',
  styleUrls: ['./list-to-dos.component.css']
})
export class ListToDosComponent implements OnInit{
 
  //to connect backend
  todos: Todo[] = []; //array of object

  
    // throw new Error('Method not implemented.');

//inject an object of TodoDataService
 constructor(private todoService:TodoDataService, private router:Router){}
 
 ngOnInit(): void{
   this.refreshToDo();
}

refreshToDo(){
  this.todoService.retriveAllTodos().subscribe(
    response=>{
      console.log(response);
      this.todos=response;
    }
  )
}


//Delete
deleteToDo(id:number){
  console.log(`deleteToDo  id=${id}`)
  //call deleteToDo from service
  this.todoService.deleteTodo(id).subscribe(
   response=>{
     this.refreshToDo();
   }
  )
}

updateToDo(id:number){
  console.log(`update record id=${id}`);
  this.router.navigate(['todo',id]);
 }


 addToDo(){
  console.log("addtodo")
  this.router.navigate(['todo',-1]); //navigate with -1 to add
  }

  
}

  
 
 

  
  // todos = [
  //   {id:1,description:'Learn To Dance'},
  //   {id:2,description:'Become Java Full Stack Developer'},
  //   {id:3,description:'Visit USA'}

  // ]

  // todos=[
  //   new Todo(1,'Learn To Dance',false,new Date()),
  //   new Todo(2,'Become Java Full Stack Developer',false,new Date()),
  //   new Todo(3,'Visit USA',true,new Date())
  // ]


// export class Todo{   //user defined typescript class
  /*
                 id:number;
                 description:string;
                 done:boolean;
                 targetDate:Date;
    constructor(id:number,description:string,done:boolean,targetDate:Date){
      this.id=id;
      this.description=description;
      this.done=done;
      this.targetDate=targetDate;
    }
  */
  //   constructor(public id:number,
  //     public description:string,
  //     public done:boolean,
  //     public targetDate:Date
  //       ) {}
    
  // }

  //create another class 
export class Todo{
  constructor(public id:number,
         public username:string,
         public description:string,
         public done:boolean,
         public targetDate:Date ){}
}